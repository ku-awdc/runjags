# runjags
An R package implementing interface utilities, model templates, parallel computing methods and additional distributions for MCMC models in JAGS

This package is in the process of being migrated from sourceforge to GitHub, along with a fairly substantial overhaul of the underlying code base. Check back for more updates soon.
