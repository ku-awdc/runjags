test_that("basic example works", {
  getex <- runjags:::example_runjags()
})
