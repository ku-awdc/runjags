#  R package runjags file R/zzz.R
#  Copyright (C) 2026 Matt Denwood
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License version
#  2 as published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  A copy of the GNU General Public License is available at
#  http://www.r-project.org/Licenses/

# Package environment variables:
.jags_pkg_env <- new.env(parent = emptyenv())
.jags_pkg_env$pkgname <- character(0)
.jags_pkg_env$libname <- character(0)
.jags_pkg_env$dyn_loaded <- FALSE
.jags_pkg_env$pkg_compile_flags <- rjags::pkg.compile.flags("ALL")

.onLoad <- function(libname, pkgname){

  ### From JAGSmodule:

  # Preserve the name of the package and lib:
  .jags_pkg_env$pkgname <- pkgname
  .jags_pkg_env$libname <- libname

  ## Ensure the version of rjags is compatible with what we need:
  rjags_version <- utils::packageVersion("rjags")
  if(rjags_version < "4-18" || (rjags_version >= "5" && rjags_version < "5.5")){
    stop("An incompatible version of rjags (", gsub(".","-",rjags_version,fixed=TRUE), ") is installed\n\tPlease install either rjags 4-18 or rjags >= 5-5", call.=FALSE)
  }

  ## Omit a warning if the major version of JAGS doesn't match:
  ss <- try(rjags::load.pkg.module(.jags_pkg_env$pkgname, .jags_pkg_env$libname, .jags_pkg_env$pkg_compile_flags, quiet=TRUE, check.only=TRUE), silent=TRUE)
  if(inherits(ss, "try-error")){
    msg <- gsub("The runjags package.*", "", gsub("Error : ", "", conditionMessage(errorCondition(ss))))
    warning(msg, "Most runjags functions will work correctly, but the internal\nJAGS module will not load. You should either re-compile\nrunjags or re-install both rjags and runjags from CRAN.", call.=FALSE)
  }
  # Note: this will be upgraded to an error if load.runjagsmodule() is called

  ### runjags specific:
  runjagsprivate$runjagsversion <- utils::packageDescription(pkgname, fields='Version')

  setopts <- mget('.runjags.options', envir=.GlobalEnv, ifnotfound=list(.runjags.options=NULL))[[1]]
  if(!is.null(setopts)){
    if(!is.list(setopts)){
      warning('Ignoring invalid (non-list) specification for .runjags.options on loading the runjags package', call.=FALSE)
    }else{
      newopts <- do.call('runjags.options', args=setopts)
    }
  }

  # Catch GUI and Rstudio specific settings: - not for Rgui (windows) though
  if(.Platform$GUI%in%c("AQUA") || Sys.getenv('RSTUDIO')!="")
    runjags.options(new.windows=FALSE)

  # To ensure that cleanup.jags is run when R is quit:
  reg.finalizer(runjagsprivate, .onDetach, onexit = TRUE)
}

.onAttach <- function(libname, pkgname){

  # Only attempt to load the package module if the dynlib is loaded:
  #if(.jags_pkg_env$dyn_loaded && .jags_pkg_env$pkgname %in% list.modules()){
  #  packageStartupMessage("module ", pkgname, " loaded")
  #}else if(.jags_pkg_env$dyn_loaded){
  #  packageStartupMessage("The JAGS module ", pkgname, " was unloaded before the package was attached")
  #}else{
  #  packageStartupMessage("The JAGS module and package dynlib for ", pkgname, " failed to load\n(this is expected during roxygenization and with devtools::load_all)")
  #}

  ### runjags specific additions:
  # This will be run after load if the package is attached:
  setopts <- mget('.runjags.options', envir=.GlobalEnv, ifnotfound=list(.runjags.options=NULL))[[1]]
  if(!is.null(setopts) && !runjags.getOption('silent.runjags')){
    packageStartupMessage(paste('Attaching runjags (version ', runjagsprivate$runjagsversion, ') and setting user-specified options', sep=''))
  }

}

.onUnload <- function(libname){
  # Ignore if the dynlib is not loaded:
  if(.jags_pkg_env$dyn_loaded){
    # First unload the JAGS module (silently), if loaded:
    if(.jags_pkg_env$pkgname %in% list.modules()){
      unload.module(.jags_pkg_env$pkgname, quiet = TRUE)
    }
    # Then the dynlib:
    library.dynam.unload(.jags_pkg_env$pkgname, libname)
  }
}

.onDetach <- function(libpath){
  ### runjags specific additions:
  # Just in case it is not always safe to try and access an element of an env that is in the process of being deleted (when R quits):
  all.folders <- try(runjags.getOption('full.cleanup'), silent=TRUE)
  if(inherits(all.folders, 'try-error')) all.folders <- FALSE
  try(cleanup.jags(all.folders=all.folders, silent=TRUE), silent=TRUE)
}
