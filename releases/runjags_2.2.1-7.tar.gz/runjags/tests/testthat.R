library(testthat)
library(runjags)

test_check("runjags")
